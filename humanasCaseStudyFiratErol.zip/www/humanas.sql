-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 21 Tem 2023, 12:28:00
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `humanas`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `jobskills`
--

DROP TABLE IF EXISTS `jobskills`;
CREATE TABLE IF NOT EXISTS `jobskills` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `personId` int NOT NULL,
  `jobId` int NOT NULL,
  `jobTitle` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `metacvinfo`
--

DROP TABLE IF EXISTS `metacvinfo`;
CREATE TABLE IF NOT EXISTS `metacvinfo` (
  `personId` int NOT NULL AUTO_INCREMENT,
  `cvId` int NOT NULL,
  `cvDownloadPath` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `cvUpdateDate` date NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`personId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personalityskillschart`
--

DROP TABLE IF EXISTS `personalityskillschart`;
CREATE TABLE IF NOT EXISTS `personalityskillschart` (
  `personId` int NOT NULL AUTO_INCREMENT,
  `skillId` int NOT NULL,
  `skillPercantage` int NOT NULL,
  PRIMARY KEY (`personId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personskills`
--

DROP TABLE IF EXISTS `personskills`;
CREATE TABLE IF NOT EXISTS `personskills` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personId` int NOT NULL,
  `skillId` int NOT NULL,
  `skillPercantage` int NOT NULL,
  `skillDescription` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personId` (`personId`),
  UNIQUE KEY `skillId` (`skillId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `skillschartinfo`
--

DROP TABLE IF EXISTS `skillschartinfo`;
CREATE TABLE IF NOT EXISTS `skillschartinfo` (
  `skillId` int NOT NULL AUTO_INCREMENT,
  `skillName` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `skillColor` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  PRIMARY KEY (`skillId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf16_turkish_ci NOT NULL,
  `password` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `nameSurname` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `jobTitle` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `profilePhotoPath` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `location` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `operation` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `workingStatus` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `language` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  `education` varchar(255) COLLATE utf16_turkish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf16 COLLATE=utf16_turkish_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `nameSurname`, `jobTitle`, `profilePhotoPath`, `location`, `operation`, `workingStatus`, `language`, `education`) VALUES
(1, 'deneme', '$2y$10$kviLA83LnG.6UEffRp7feufWTGSGGpeDMoWmM.sngwUyAecPFb/qy', '2023-07-20 20:50:56', '', '', '', '', '', '', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
