<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: main2.php");
    exit;
}

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if username is empty
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter username.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Check if password is empty
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    // Validate credentials
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";

        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set parameters
            $param_username = $username;

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Store result
                mysqli_stmt_store_result($stmt);

                // Check if username exists, if yes then verify password
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;

                            // Redirect user to welcome page
                            header("location: main2.php");
                        } else {
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else {
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }

    // Close connection
    mysqli_close($link);
}
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Humanas - Login Page</title>
    <link rel="stylesheet" href="Assets/css/circle-percantage-graph.css">
    <link rel="stylesheet" href="Assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="Assets/css/form.css">
    <link rel="stylesheet" href="Assets/css/owl.carousel.min.css">
    <script type="text/javascript" src="fontawesome.js"></script>
    <script type="text/javascript" src="jquery.min.js"></script>
    <script type="text/javascript" src="owl.carousel.js"></script>
    <style>
        body {
            font-family: 'Roboto', sans-serif !important;
            background: #FFFFFF 0% 0% no-repeat padding-box;
        }

        .mainBox {
            margin-top: 10%;
            width: 718px;
            height: auto;
            max-width: 840px;
            border: 1px solid #EAEAEA;
            background: #FFFFFF;
            box-shadow: 0px 0px 20px #0000001A;
            border: 1px solid #EAEAEA;
        }

        .mainBox h1 {
            margin-top: 55px;
            font-size: 36px;
            text-align: left;
            font: normal normal bold 36px/60px Roboto Condensed;
            letter-spacing: 0px;
            color: #000000;
            opacity: 1;
            padding-left: 55px;
        }

        .mainBox p {
            text-align: left;
            font: normal normal normal 18px/24px Roboto Condensed;
            letter-spacing: 0px;
            color: #404040;
            opacity: 1;
            padding-left: 55px;
            padding-right: 64px;
            margin-bottom: 35px;
        }

        .linkedInBox {
            background: #137BB8 0% 0% no-repeat padding-box;
            border: 1px solid #095B8C;
            border-radius: 5px;
            opacity: 1;
            height: 52px;
            margin: 0 auto;
            margin-left: 55px;
            margin-right: 64px;
        }

        .linkedInBox p {
            font-family: Roboto;
            font-weight: 100 !important;
            text-align: center;
            color: #FFFFFF;
            opacity: 1;
            margin-left: -56px;
            position: relative;
            margin: 10px 0 0 0;
            padding-left: 55px;
            padding-right: 55px;
        }

        .linkedInBox img {
            background: #117BB8 0% 0% no-repeat padding-box;
            border: 1px solid #095B8C;
            border-radius: 5px;
            opacity: 1;
            text-decoration: none;
            position: absolute;
        }

        @media (max-width: 426px) {
            .linkedInBox p {
                font-size: 15px;
                padding-right: 9%;
            }
        }

        @media (max-width: 385px) {
            .linkedInBox p {
                font-size: 11px;
            }
        }

        @media (max-width: 320px) {
            .linkedInBox p {
                font-size: 9px;
            }
        }

        .submitBox {
            background: #0B1656 0% 0% no-repeat padding-box;
            border: 1px solid #000000;
            opacity: 1;
            color: #FFFFFF;
            text-align: center;
            font-weight: bold;
            padding: 15px 0 15px 0;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="d-flex justify-content-center">
                <div class="mainBox">

                    <h1>Employee Login</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the
                        industry’s standard dummy text ever since the 1500s, when an unknown printer took</p>
                    <div class="linkedInBox">
                        <img src="Assets/img/icons8-linkedin.svg">
                        <p>Sign in with Linked In</p>
                    </div>

                    <h1>Company Login</h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the
                        industry’s standard dummy text ever since the 1500s, when an unknown printer took</p>
                    <div>
                        <form class="custom-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"
                            method="post">
                            <div class="form-group" ng-class="{'not-empty': userName.length}">
                                <input type="text" name="username"
                                    class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>"
                                    value="<?php echo $username; ?>" id="user" ng-model="userName" />
                                <label for="user" class="animated-label">Username</label>
                            </div>
                            <div class="form-group" ng-class="{'not-empty': passWord.length}">
                                <input type="password" name="password"
                                    class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>"
                                    id="pass" ng-model="passWord" />
                                <label for="pass" class="animated-label">Password</label>
                            </div>
                            <a style="text-decoration: none; color: #FFFFFF;">
                                <div class="submitBox" style="cursor: pointer;">
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary" value="Login">
                                    </div>
                                </div>
                            </a>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>